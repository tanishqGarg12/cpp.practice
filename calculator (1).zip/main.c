#include <stdio.h>

int main()
{
    char op;
    float a,b,r;
    printf("enter oprator:");
    scanf("%c",&op);
    switch(op){
        case'+':
        printf("two no:");
        scanf("%f %f",&a,&b);
        r=a+b;
        printf("%f+%f=%f",a,b,r);
        break;
          case'-':
        printf("two no:");
        scanf("%f %f",&a,&b);
        r=a-b;
        printf("%f -%f=%f",a,b,r);
        break;
          case'*':
        printf("two no:");
        scanf("%f %f",&a,&b);
        r=a*b;
        printf("%f* %f=%f",a,b,r);
        break;
          case'/':
        printf("two no:");
        scanf("%f %f",&a,&b);
        r=a/b;
        printf("%f /%f=%f",a,b,r);
        break;
    }
    return 0;
}
